
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
require("dotenv").config();

require("./config/db");

const Admin = require("./models/Admin");

const createAdmin = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    const existingAdmin = await Admin.findOne({
      email: "admin@shopme.com",
    });

    if (existingAdmin) {
      console.log("Admin already exists!");
      return;
    }

    const hashedPassword = await bcrypt.hash("Admin@123", 10);

    await Admin.create({
      name: "ShopMe Admin",
      email: "admin@shopme.com",
      password: hashedPassword,
    });

    console.log("Admin created successfully!");
  } catch (error) {
    console.log("Error:", error.message);
  } finally {
    await mongoose.disconnect();
  }
};

createAdmin();
