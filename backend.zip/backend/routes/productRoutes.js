
const express = require("express");
const router = express.Router();

const {
  getProducts,
  getProductById,
  getProductsByCategory,
} = require("../controllers/productController");

// Get all products
router.get("/", getProducts);

// Get products by category
router.get("/category/:categoryId", getProductsByCategory);

// Get a single product
router.get("/:id", getProductById);

module.exports = router;

