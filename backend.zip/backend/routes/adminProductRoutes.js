
const express = require("express");
const router = express.Router();

const {
  getAllProducts,
  addProduct,
  updateProduct,
  deleteProduct,
} = require("../controllers/adminProductController");

const { protectAdmin } = require("../middleware/adminMiddleware");

// Admin product routes
router.get("/", protectAdmin, getAllProducts);
router.post("/", protectAdmin, addProduct);
router.put("/:id", protectAdmin, updateProduct);
router.delete("/:id", protectAdmin, deleteProduct);

module.exports = router;
