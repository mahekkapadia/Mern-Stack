
const express = require("express");
const router = express.Router();

const {
  loginAdmin,
  getAdminProfile,
} = require("../controllers/adminController");

const { protectAdmin } = require("../middleware/adminMiddleware");

const adminCategoryRoutes = require("./adminCategoryRoutes");
const adminProductRoutes = require("./adminProductRoutes");

// Admin login
router.post("/login", loginAdmin);

// Get logged-in admin's profile
router.get("/profile", protectAdmin, getAdminProfile);

// Admin category management
router.use("/categories", adminCategoryRoutes);

// Admin product management
router.use("/products", adminProductRoutes);

module.exports = router;
