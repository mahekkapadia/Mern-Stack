
const express = require("express");
const router = express.Router();

const {
  getAllCategories,
  addCategory,
  updateCategory,
  deleteCategory,
} = require("../controllers/adminCategoryController");

const { protectAdmin } = require("../middleware/adminMiddleware");

// Admin category routes
router.get("/", protectAdmin, getAllCategories);
router.post("/", protectAdmin, addCategory);
router.put("/:id", protectAdmin, updateCategory);
router.delete("/:id", protectAdmin, deleteCategory);

module.exports = router;
