
const mongoose = require("mongoose");
const Category = require("../models/Category");

// Get all active categories
const getCategories = async (req, res) => {
  try {
    const categories = await Category.find({
      status: "active",
    }).sort({ createdAt: -1 });

    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get a single category
const getCategoryById = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        message: "Invalid category ID",
      });
    }

    const category = await Category.findOne({
      _id: req.params.id,
      status: "active",
    });

    if (!category) {
      return res.status(404).json({
        message: "Category not found",
      });
    }

    res.status(200).json(category);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getCategories,
  getCategoryById,
};
