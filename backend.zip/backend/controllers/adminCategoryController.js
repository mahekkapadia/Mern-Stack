
const mongoose = require("mongoose");
const Category = require("../models/Category");
const Product = require("../models/Product");

// Generate category slug
const generateSlug = (name) => {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
};

// Get all categories
const getAllCategories = async (req, res) => {
  try {
    const categories = await Category.find().sort({ createdAt: -1 });

    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Add a new category
const addCategory = async (req, res) => {
  try {
    const { name, description, image, status } = req.body;

    if (typeof name !== "string" || !name.trim()) {
      return res.status(400).json({
        message: "Category name is required!",
      });
    }

    if (
      status !== undefined &&
      !["active", "inactive"].includes(status)
    ) {
      return res.status(400).json({
        message: "Invalid category status!",
      });
    }

    const slug = generateSlug(name);

    if (!slug) {
      return res.status(400).json({
        message: "Please enter a valid category name!",
      });
    }

    const existingCategory = await Category.findOne({ slug });

    if (existingCategory) {
      return res.status(400).json({
        message: "Category already exists!",
      });
    }

    const category = await Category.create({
      name: name.trim(),
      slug,
      description,
      image,
      status,
    });

    res.status(201).json({
      message: "Category added successfully!",
      category,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update a category
const updateCategory = async (req, res) => {
  try {
    const { name, description, image, status } = req.body;

    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        message: "Invalid category ID!",
      });
    }

    if (
      status !== undefined &&
      !["active", "inactive"].includes(status)
    ) {
      return res.status(400).json({
        message: "Invalid category status!",
      });
    }

    const category = await Category.findById(req.params.id);

    if (!category) {
      return res.status(404).json({
        message: "Category not found!",
      });
    }

    if (name !== undefined) {
      if (typeof name !== "string" || !name.trim()) {
        return res.status(400).json({
          message: "Category name cannot be empty!",
        });
      }

      const newSlug = generateSlug(name);

      if (!newSlug) {
        return res.status(400).json({
          message: "Please enter a valid category name!",
        });
      }

      const existingCategory = await Category.findOne({
        slug: newSlug,
        _id: { $ne: category._id },
      });

      if (existingCategory) {
        return res.status(400).json({
          message: "Another category already uses this name!",
        });
      }

      category.name = name.trim();
      category.slug = newSlug;
    }

    category.description = description ?? category.description;
    category.image = image ?? category.image;
    category.status = status ?? category.status;

    await category.save();

    res.status(200).json({
      message: "Category updated successfully!",
      category,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete a category
const deleteCategory = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        message: "Invalid category ID!",
      });
    }

    const category = await Category.findById(req.params.id);

    if (!category) {
      return res.status(404).json({
        message: "Category not found!",
      });
    }

    const products = await Product.findOne({
      category: category._id,
    });

    if (products) {
      return res.status(400).json({
        message: "Cannot delete category because products are assigned to it!",
      });
    }

    await category.deleteOne();

    res.status(200).json({
      message: "Category deleted successfully!",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllCategories,
  addCategory,
  updateCategory,
  deleteCategory,
};
