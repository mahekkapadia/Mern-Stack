
const mongoose = require("mongoose");
const Product = require("../models/Product");

// Get all active products
const getProducts = async (req, res) => {
  try {
    const products = await Product.find({
      status: "active",
    })
      .populate({
        path: "category",
        match: { status: "active" },
      })
      .sort({ createdAt: -1 });

    const activeProducts = products.filter(
      (product) => product.category
    );

    res.status(200).json(activeProducts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get a single active product
const getProductById = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        message: "Invalid product ID",
      });
    }

    const product = await Product.findOne({
      _id: req.params.id,
      status: "active",
    }).populate({
      path: "category",
      match: { status: "active" },
    });

    if (!product || !product.category) {
      return res.status(404).json({
        message: "Product not found",
      });
    }

    res.status(200).json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get active products by category
const getProductsByCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;

    if (!mongoose.isValidObjectId(categoryId)) {
      return res.status(400).json({
        message: "Invalid category ID",
      });
    }

    const categoryExists = await mongoose.model("Category").findOne({
      _id: categoryId,
      status: "active",
    });

    if (!categoryExists) {
      return res.status(404).json({
        message: "Category not found",
      });
    }

    const products = await Product.find({
      category: categoryId,
      status: "active",
    })
      .populate("category", "name slug")
      .sort({ createdAt: -1 });

    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getProducts,
  getProductById,
  getProductsByCategory,
};
