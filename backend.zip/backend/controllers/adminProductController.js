
const mongoose = require("mongoose");
const Product = require("../models/Product");
const Category = require("../models/Category");

// Generate product slug
const generateSlug = (name) => {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
};

// Get all products
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find()
      .populate("category", "name slug")
      .sort({ createdAt: -1 });

    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Add a new product
const addProduct = async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      image,
      category,
      stock,
      status,
    } = req.body;

    if (
      typeof name !== "string" ||
      !name.trim() ||
      typeof description !== "string" ||
      !description.trim() ||
      price === undefined ||
      category === undefined
    ) {
      return res.status(400).json({
        message: "Please fill all required product fields!",
      });
    }

    if (
      price === "" ||
      !Number.isFinite(Number(price)) ||
      Number(price) < 0
    ) {
      return res.status(400).json({
        message: "Price must be a valid non-negative number!",
      });
    }

    if (
      stock !== undefined &&
      (stock === "" ||
        !Number.isInteger(Number(stock)) ||
        Number(stock) < 0)
    ) {
      return res.status(400).json({
        message: "Stock must be a non-negative whole number!",
      });
    }

    if (!mongoose.isValidObjectId(category)) {
      return res.status(400).json({
        message: "Invalid category ID!",
      });
    }

    if (
      status !== undefined &&
      !["active", "inactive"].includes(status)
    ) {
      return res.status(400).json({
        message: "Invalid product status!",
      });
    }

    const categoryExists = await Category.findById(category);

    if (!categoryExists) {
      return res.status(400).json({
        message: "Selected category does not exist!",
      });
    }

    const slug = generateSlug(name);

    if (!slug) {
      return res.status(400).json({
        message: "Please enter a valid product name!",
      });
    }

    const existingProduct = await Product.findOne({ slug });

    if (existingProduct) {
      return res.status(400).json({
        message: "Product already exists!",
      });
    }

    const product = await Product.create({
      name: name.trim(),
      slug,
      description: description.trim(),
      price: Number(price),
      image,
      category,
      stock: stock === undefined ? 0 : Number(stock),
      status,
    });

    res.status(201).json({
      message: "Product added successfully!",
      product,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update a product
const updateProduct = async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      image,
      category,
      stock,
      status,
    } = req.body;

    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        message: "Invalid product ID!",
      });
    }

    if (
      status !== undefined &&
      !["active", "inactive"].includes(status)
    ) {
      return res.status(400).json({
        message: "Invalid product status!",
      });
    }

    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        message: "Product not found!",
      });
    }

    if (name !== undefined) {
      if (typeof name !== "string" || !name.trim()) {
        return res.status(400).json({
          message: "Product name cannot be empty!",
        });
      }

      const newSlug = generateSlug(name);

      if (!newSlug) {
        return res.status(400).json({
          message: "Please enter a valid product name!",
        });
      }

      const existingProduct = await Product.findOne({
        slug: newSlug,
        _id: { $ne: product._id },
      });

      if (existingProduct) {
        return res.status(400).json({
          message: "Another product already uses this name!",
        });
      }

      product.name = name.trim();
      product.slug = newSlug;
    }

    if (description !== undefined) {
      if (typeof description !== "string" || !description.trim()) {
        return res.status(400).json({
          message: "Product description cannot be empty!",
        });
      }

      product.description = description.trim();
    }

    if (price !== undefined) {
      if (
        price === "" ||
        !Number.isFinite(Number(price)) ||
        Number(price) < 0
      ) {
        return res.status(400).json({
          message: "Price must be a valid non-negative number!",
        });
      }

      product.price = Number(price);
    }

    if (stock !== undefined) {
      if (
        stock === "" ||
        !Number.isInteger(Number(stock)) ||
        Number(stock) < 0
      ) {
        return res.status(400).json({
          message: "Stock must be a non-negative whole number!",
        });
      }

      product.stock = Number(stock);
    }

    if (category !== undefined) {
      if (!mongoose.isValidObjectId(category)) {
        return res.status(400).json({
          message: "Invalid category ID!",
        });
      }

      const categoryExists = await Category.findById(category);

      if (!categoryExists) {
        return res.status(400).json({
          message: "Selected category does not exist!",
        });
      }

      product.category = category;
    }

    product.image = image ?? product.image;
    product.status = status ?? product.status;

    await product.save();

    res.status(200).json({
      message: "Product updated successfully!",
      product,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete a product
const deleteProduct = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        message: "Invalid product ID!",
      });
    }

    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        message: "Product not found!",
      });
    }

    await product.deleteOne();

    res.status(200).json({
      message: "Product deleted successfully!",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllProducts,
  addProduct,
  updateProduct,
  deleteProduct,
};
