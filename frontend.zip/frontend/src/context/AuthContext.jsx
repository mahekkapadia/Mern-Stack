
import { createContext, useContext, useEffect, useState } from "react";
import api from "../api";

// Create authentication context
const AuthContext = createContext();

// Authentication provider
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(
    localStorage.getItem("token")
  );
  const [loading, setLoading] = useState(true);

  // Check whether user is already logged in
  useEffect(() => {
    const fetchProfile = async () => {
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const response = await api.get("/auth/profile");
        setUser(response.data);
      } catch (error) {
        localStorage.removeItem("token");
        setToken(null);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [token]);

  // Save user and token after login or registration
  const saveAuthData = (data) => {
    localStorage.setItem("token", data.token);
    setToken(data.token);
    setUser({
      _id: data._id,
      name: data.name,
      email: data.email,
    });
  };

  // Register user
  const register = async (name, email, password) => {
    const response = await api.post("/auth/register", {
      name,
      email,
      password,
    });

    saveAuthData(response.data);
    return response.data;
  };

  // Login user
  const login = async (email, password) => {
    const response = await api.post("/auth/login", {
      email,
      password,
    });

    saveAuthData(response.data);
    return response.data;
  };

  // Logout user
  const logout = () => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        isAuthenticated: Boolean(token && user),
        register,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use authentication
export function useAuth() {
  return useContext(AuthContext);
}
