
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

function ProductCard({ product }) {
  return (
    <div className="group bg-white border border-beige-200 rounded-xl overflow-hidden hover:shadow-md transition duration-300">

      <Link to={`/products/${product._id}`}>
        <div className="h-60 bg-beige-100 overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
          />
        </div>
      </Link>

      <div className="p-5">

        <p className="text-xs uppercase tracking-widest text-beige-600 mb-2">
          {product.category?.name || product.category || "Collection"}
        </p>

        <Link to={`/products/${product._id}`}>
          <h3 className="text-base font-medium text-beige-900 leading-snug min-h-11">
            {product.name}
          </h3>
        </Link>

        <div className="flex items-center justify-between mt-4">

          <span className="text-lg font-semibold text-beige-900">
            ₹{Number(product.price).toLocaleString("en-IN")}
          </span>

          <span className="text-xs text-beige-600">
            {product.stock > 0 ? "In stock" : "Out of stock"}
          </span>

        </div>

        <Link
          to={`/products/${product._id}`}
          className="mt-5 flex items-center justify-between border-t border-beige-200 pt-4 text-sm font-medium text-beige-700 hover:text-beige-500 transition"
        >
          View details
          <ArrowUpRight size={17} />
        </Link>

      </div>
    </div>
  );
}

export default ProductCard;
