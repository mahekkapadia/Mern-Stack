
import { Link, NavLink, useNavigate } from "react-router-dom";
import { ShoppingBag, UserRound, LogOut } from "lucide-react";
import { useAuth } from "../context/AuthContext";

function Navbar() {
  const { user, isAuthenticated, logout, loading } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="bg-white border-b border-beige-200">
      <div className="max-w-7xl mx-auto px-8 h-20 flex items-center justify-between">

        {/* Logo */}
        <Link
          to="/"
          className="text-2xl font-semibold tracking-tight text-beige-900"
        >
          Shop<span className="text-beige-600">Hub</span>
        </Link>

        {/* Navigation Links */}
        <div className="flex items-center gap-7 text-sm text-beige-800">

          <NavLink
            to="/"
            className="hover:text-beige-600 transition"
          >
            Home
          </NavLink>

          <NavLink
            to="/cart"
            className="flex items-center gap-2 hover:text-beige-600 transition"
          >
            <ShoppingBag size={18} strokeWidth={1.6} />
            Cart
          </NavLink>

          {!loading && (
            <>
              {isAuthenticated ? (
                <>
                  <span className="flex items-center gap-2">
                    <UserRound size={18} />
                    {user?.name}
                  </span>

                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 px-4 py-2.5 border border-beige-300 rounded-md hover:bg-beige-100 transition"
                  >
                    <LogOut size={17} />
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <NavLink
                    to="/login"
                    className="flex items-center gap-2 hover:text-beige-600 transition"
                  >
                    <UserRound size={18} strokeWidth={1.6} />
                    Login
                  </NavLink>

                  <NavLink
                    to="/register"
                    className="px-5 py-2.5 bg-beige-600 text-white rounded-md hover:bg-beige-700 transition"
                  >
                    Register
                  </NavLink>
                </>
              )}
            </>
          )}

        </div>
      </div>
    </nav>
  );
}

export default Navbar;
