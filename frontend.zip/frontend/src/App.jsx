
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { AuthProvider } from "./context/AuthContext";

import Navbar from "./components/Navbar";

import Home from "./pages/Home";
import Category from "./pages/Category";
import Product from "./pages/Product";
import Cart from "./pages/Cart";
import Login from "./pages/Login";
import Register from "./pages/Register";

function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-beige-50">
      <h1 className="text-3xl font-semibold text-beige-900">
        404 - Page Not Found
      </h1>

      <p className="text-beige-600 mt-3">
        The page you are looking for does not exist.
      </p>

      <a href="/" className="mt-6 text-beige-700 underline">
        Return to Home
      </a>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path="/" element={<Home />} />

          <Route path="/categories/:id" element={<Category />} />

          <Route path="/products/:id" element={<Product />} />

          <Route path="/cart" element={<Cart />} />

          <Route path="/login" element={<Login />} />

          <Route path="/register" element={<Register />} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
