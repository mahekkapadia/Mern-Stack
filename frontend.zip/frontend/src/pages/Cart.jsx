
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import api from "../api";

function Cart() {
  const navigate = useNavigate();

  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [updating, setUpdating] = useState(false);

  // Fetch cart
  const fetchCart = async () => {
    try {
      const response = await api.get("/cart");
      setCart(response.data);
      setError("");
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to load your cart."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!localStorage.getItem("token")) {
      navigate("/login");
      return;
    }

    fetchCart();
  }, []);

  // Update product quantity
  const updateQuantity = async (itemId, quantity) => {
    try {
      setUpdating(true);

      await api.patch(`/cart/items/${itemId}`, {
        quantity,
      });

      await fetchCart();
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to update quantity."
      );
    } finally {
      setUpdating(false);
    }
  };

  // Remove product
  const removeItem = async (itemId) => {
    try {
      setUpdating(true);

      await api.delete(`/cart/items/${itemId}`);

      await fetchCart();
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to remove product."
      );
    } finally {
      setUpdating(false);
    }
  };

  // Clear entire cart
  const clearCart = async () => {
    try {
      setUpdating(true);

      await api.delete("/cart");

      await fetchCart();
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to clear cart."
      );
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-beige-50">
        <p className="text-beige-600">Loading your cart...</p>
      </div>
    );
  }

  if (!cart) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-beige-50">
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-beige-50">
      <div className="max-w-7xl mx-auto px-8 py-12">

        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-xs uppercase tracking-widest text-beige-600 mb-2">
              Your shopping bag
            </p>

            <h1 className="text-3xl font-semibold text-beige-900">
              Shopping Cart
            </h1>
          </div>

          {cart.items.length > 0 && (
            <button
              onClick={clearCart}
              disabled={updating}
              className="text-sm text-red-600 hover:text-red-800 disabled:opacity-50"
            >
              Clear Cart
            </button>
          )}
        </div>

        {error && (
          <p className="text-sm text-red-600 mb-5">{error}</p>
        )}

        {cart.items.length === 0 ? (
          <div className="bg-white border border-beige-200 rounded-xl py-20 text-center">
            <ShoppingBag
              size={42}
              className="mx-auto text-beige-400 mb-5"
            />

            <h2 className="text-xl font-semibold text-beige-900">
              Your cart is empty
            </h2>

            <p className="text-beige-600 mt-2">
              Looks like you haven't added anything yet.
            </p>

            <Link
              to="/"
              className="inline-block mt-7 bg-beige-600 text-white px-6 py-3 rounded-lg hover:bg-beige-700 transition"
            >
              Start Shopping
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-5">

              {cart.items.map((item) => {
                const product = item.product;

                return (
                  <div
                    key={item._id}
                    className="bg-white border border-beige-200 rounded-xl p-5 flex flex-col sm:flex-row gap-6"
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full sm:w-36 h-36 object-cover rounded-lg bg-beige-100"
                    />

                    <div className="flex-1">
                      <h3 className="text-lg font-medium text-beige-900">
                        {product.name}
                      </h3>

                      <p className="text-beige-600 mt-2">
                        ₹{Number(product.price).toLocaleString("en-IN")}
                      </p>

                      <div className="flex flex-wrap items-center justify-between mt-5 gap-4">

                        {/* Quantity Selector */}
                        <div className="flex items-center border border-beige-300 rounded-lg">

                          <button
                            onClick={() =>
                              updateQuantity(item._id, item.quantity - 1)
                            }
                            disabled={updating || item.quantity <= 1}
                            className="p-2 hover:bg-beige-100 disabled:opacity-40"
                          >
                            <Minus size={15} />
                          </button>

                          <span className="px-4 text-beige-900">
                            {item.quantity}
                          </span>

                          <button
                            onClick={() =>
                              updateQuantity(item._id, item.quantity + 1)
                            }
                            disabled={
                              updating ||
                              item.quantity >= product.stock
                            }
                            className="p-2 hover:bg-beige-100 disabled:opacity-40"
                          >
                            <Plus size={15} />
                          </button>

                        </div>

                        <p className="font-semibold text-beige-900">
                          ₹{Number(item.itemTotal).toLocaleString("en-IN")}
                        </p>

                        <button
                          onClick={() => removeItem(item._id)}
                          disabled={updating}
                          className="text-red-600 hover:text-red-800 disabled:opacity-50"
                          title="Remove product"
                        >
                          <Trash2 size={19} />
                        </button>

                      </div>
                    </div>
                  </div>
                );
              })}

            </div>

            {/* Order Summary */}
            <div className="bg-white border border-beige-200 rounded-xl p-6 h-fit">

              <h2 className="text-xl font-semibold text-beige-900 mb-6">
                Order Summary
              </h2>

              <div className="flex justify-between text-sm text-beige-700 mb-4">
                <span>Total Items</span>
                <span>
                  {cart.items.reduce(
                    (total, item) => total + item.quantity,
                    0
                  )}
                </span>
              </div>

              <div className="border-t border-beige-200 pt-5 mt-5">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-beige-900">
                    Total Amount
                  </span>

                  <span className="text-xl font-semibold text-beige-900">
                    ₹{Number(cart.totalAmount).toLocaleString("en-IN")}
                  </span>
                </div>
              </div>

              <p className="text-xs text-beige-500 mt-5">
                Checkout and payment functionality is not included in the current project scope.
              </p>

              <Link
                to="/"
                className="block text-center mt-6 border border-beige-300 text-beige-800 py-3 rounded-lg hover:bg-beige-100 transition"
              >
                Continue Shopping
              </Link>

            </div>
          </div>
        )}

      </div>
    </main>
  );
}

export default Cart;
