
import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { ShoppingBag, ArrowLeft, Minus, Plus } from "lucide-react";
import api from "../api";

function Product() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);

        const response = await api.get(`/products/${id}`);

        setProduct(response.data.product || response.data);
      } catch (error) {
        console.error(error);
        setProduct(null);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  const addToCart = async () => {
    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login");
      return;
    }

    try {
      setAdding(true);
      setMessage("");

      await api.post("/cart/items", {
        productId: product._id,
        quantity: quantity,
      });

      setMessage("Product added to your cart successfully!");
    } catch (error) {
      setMessage(
        error.response?.data?.message ||
        "Unable to add product to cart."
      );
    } finally {
      setAdding(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-beige-50">
        <p className="text-beige-600">Loading product...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-beige-50">
        <h2 className="text-2xl font-semibold text-beige-900">
          Product not found
        </h2>

        <Link to="/" className="mt-5 text-beige-600 underline">
          Return to Home
        </Link>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-beige-50">
      <div className="max-w-7xl mx-auto px-8 py-12">

        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-beige-600 hover:text-beige-900 mb-10"
        >
          <ArrowLeft size={17} />
          Continue Shopping
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">

          {/* Product Image */}
          <div className="bg-white border border-beige-200 rounded-2xl overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-[450px] object-contain p-8"
            />
          </div>

          {/* Product Information */}
          <div className="py-4">

            <p className="text-xs uppercase tracking-widest text-beige-600 mb-4">
              {product.category?.name || "ShopHub Collection"}
            </p>

            <h1 className="text-3xl md:text-4xl font-semibold text-beige-900 leading-tight">
              {product.name}
            </h1>

            <p className="text-2xl font-semibold text-beige-800 mt-6">
              ₹{Number(product.price).toLocaleString("en-IN")}
            </p>

            <div className="border-t border-beige-200 my-7"></div>

            <h3 className="font-medium text-beige-900 mb-3">
              Product Description
            </h3>

            <p className="text-beige-700 leading-7">
              {product.description || "No description available."}
            </p>

            <div className="mt-7">
              <p className="text-sm text-beige-600">
                Availability:
                <span className={`ml-2 font-medium ${
                  product.stock > 0
                    ? "text-green-700"
                    : "text-red-600"
                }`}>
                  {product.stock > 0
                    ? `${product.stock} available`
                    : "Out of stock"}
                </span>
              </p>
            </div>

            {/* Quantity Selector */}
            {product.stock > 0 && (
              <div className="mt-8">
                <p className="text-sm font-medium text-beige-900 mb-3">
                  Quantity
                </p>

                <div className="flex items-center border border-beige-300 rounded-lg w-fit">

                  <button
                    onClick={() =>
                      setQuantity((previous) =>
                        Math.max(1, previous - 1)
                      )
                    }
                    disabled={quantity <= 1}
                    className="p-3 hover:bg-beige-100 disabled:opacity-40"
                  >
                    <Minus size={16} />
                  </button>

                  <span className="px-5 text-beige-900">
                    {quantity}
                  </span>

                  <button
                    onClick={() =>
                      setQuantity((previous) =>
                        Math.min(product.stock, previous + 1)
                      )
                    }
                    disabled={quantity >= product.stock}
                    className="p-3 hover:bg-beige-100 disabled:opacity-40"
                  >
                    <Plus size={16} />
                  </button>

                </div>
              </div>
            )}

            {/* Add to Cart */}
            <button
              onClick={addToCart}
              disabled={adding || product.stock <= 0}
              className="mt-8 w-full md:w-72 flex items-center justify-center gap-3 bg-beige-600 text-white py-3.5 rounded-lg hover:bg-beige-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingBag size={18} />
              {adding
                ? "Adding..."
                : product.stock > 0
                  ? "Add to Cart"
                  : "Out of Stock"}
            </button>

            {message && (
              <p className="mt-4 text-sm text-beige-700">
                {message}
              </p>
            )}

          </div>
        </div>
      </div>
    </main>
  );
}

export default Product;
