
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      setLoading(true);

      await login(email, password);

      navigate("/");
    } catch (err) {
      setError(
        err.response?.data?.message || "Unable to login. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-beige-50 flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md bg-white border border-beige-200 rounded-2xl p-8 shadow-sm">

        <div className="text-center mb-8">
          <p className="text-xs uppercase tracking-widest text-beige-600 mb-3">
            Welcome back
          </p>

          <h1 className="text-3xl font-semibold text-beige-900">
            Login to ShopHub
          </h1>

          <p className="text-sm text-beige-600 mt-3">
            Enter your details to access your account.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">

          <div>
            <label className="block text-sm font-medium text-beige-800 mb-2">
              Email Address
            </label>

            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
              className="w-full border border-beige-300 rounded-lg px-4 py-3 outline-none focus:border-beige-600"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-beige-800 mb-2">
              Password
            </label>

            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
              className="w-full border border-beige-300 rounded-lg px-4 py-3 outline-none focus:border-beige-600"
            />
          </div>

          {error && (
            <p className="text-sm text-red-600">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-beige-600 text-white py-3 rounded-lg hover:bg-beige-700 transition disabled:opacity-50"
          >
            {loading ? "Logging in..." : "Login"}
          </button>

        </form>

        <p className="text-center text-sm text-beige-600 mt-7">
          Don't have an account?{" "}
          <Link
            to="/register"
            className="font-medium text-beige-800 underline"
          >
            Register here
          </Link>
        </p>

      </div>
    </main>
  );
}

export default Login;
