
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import ProductCard from "../components/ProductCard";

function Home() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Temporary products for frontend preview
  const demoProducts = [
    {
      _id: "demo1",
      name: "Ultra-Slim Mechanical Keyboard",
      category: "Accessories",
      price: 3499,
      stock: 15,
      image:
        "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=700",
    },
    {
      _id: "demo2",
      name: "Pro Wireless ANC Headphones",
      category: "Electronics",
      price: 4999,
      stock: 12,
      image:
        "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700",
    },
    {
      _id: "demo3",
      name: "Ergonomic Precision Wireless Mouse",
      category: "Accessories",
      price: 1899,
      stock: 20,
      image:
        "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=700",
    },
    {
      _id: "demo4",
      name: "Next-Gen Wireless Gaming Controller",
      category: "Gaming",
      price: 4299,
      stock: 8,
      image:
        "https://images.unsplash.com/photo-1600080972464-8e5f35f63d08?w=700",
    },
  ];

  useEffect(() => {
    const fetchHomeData = async () => {
      try {
        const [productRes, categoryRes] = await Promise.all([
          api.get("/products"),
          api.get("/categories"),
        ]);

        const productData = productRes.data.products || productRes.data;
        const categoryData = categoryRes.data.categories || categoryRes.data;

        setProducts(productData);
        setCategories(categoryData);
      } catch (err) {
        console.log("Backend not connected. Showing demo products.");

        setProducts(demoProducts);
        setError("Showing demo products until the backend is connected.");
      } finally {
        setLoading(false);
      }
    };

    fetchHomeData();
  }, []);

  
  return (
    <main className="min-h-screen bg-beige-50">

      <div className="max-w-7xl mx-auto px-8 py-14">

        {/* Welcome */}
        <section className="mb-14">
          <p className="text-sm tracking-widest uppercase text-beige-600 mb-3">
            Welcome to ShopHub
          </p>

          <h1 className="text-4xl md:text-5xl font-semibold tracking-tight text-beige-900">
            Find things you'll love.
          </h1>

          <p className="mt-4 text-beige-700 text-base max-w-xl leading-7">
            Discover thoughtfully selected products for your everyday needs.
            A little something for everyone.
          </p>
        </section>

        {/* Categories */}
        {categories.length > 0 && (
          <section className="mb-14">
            <h2 className="text-xl font-semibold text-beige-900 mb-5">
              Explore categories
            </h2>

            <div className="flex flex-wrap gap-3">
              {categories.map((category) => (
                <Link
                  key={category._id}
                  to={`/categories/${category._id}`}
                  className="px-5 py-2.5 rounded-full border border-beige-300 bg-white text-sm text-beige-800 hover:bg-beige-100 transition"
                >
                  {category.name}
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Products */}
        <section>
          <div className="flex items-end justify-between mb-7">
            <div>
              <p className="text-xs uppercase tracking-widest text-beige-600 mb-2">
                Curated for you
              </p>

              <h2 className="text-2xl font-semibold text-beige-900">
                Trending products
              </h2>
            </div>

            <p className="text-sm text-beige-600">
              {products.length} products
            </p>
          </div>

          {error && (
            <p className="text-sm text-beige-700 mb-5">
              {error}
            </p>
          )}

          {loading ? (
            <p className="text-center py-16 text-beige-600">
              Loading products...
            </p>
          ) : products.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
            </div>
          ) : (
            <p className="text-center py-16 text-beige-600">
              No products available yet.
            </p>
          )}
        </section>

      </div>
    </main>
  );
}

export default Home;
