
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api";
import ProductCard from "../components/ProductCard";
import { ArrowLeft } from "lucide-react";

function Category() {
  const { id } = useParams();

  const [category, setCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchCategoryProducts = async () => {
      try {
        setLoading(true);
        setError("");

        const [categoryRes, productRes] = await Promise.all([
          api.get(`/categories/${id}`),
          api.get(`/products/category/${id}`),
        ]);

        setCategory(categoryRes.data.category || categoryRes.data);
        
        console.log("Category details:", categoryRes.data);
        console.log("Products:", productRes.data);

        const productData =
          productRes.data.products || productRes.data;

        setProducts(productData);
      } catch (err) {
        console.error(err);
        setError("Unable to load this category. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchCategoryProducts();
  }, [id]);

  return (
    <main className="min-h-screen bg-beige-50">
      <div className="max-w-7xl mx-auto px-8 py-12">

        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-beige-600 hover:text-beige-900 mb-9"
        >
          <ArrowLeft size={17} />
          Back to Home
        </Link>

        <section className="mb-10">
          <p className="text-xs uppercase tracking-widest text-beige-600 mb-3">
            Shop by collection
          </p>

          <h1 className="text-4xl font-semibold text-beige-900">
            {category?.name || "Category"}
          </h1>

          <p className="text-beige-600 mt-3 max-w-2xl">
            {category?.description ||
              "Explore products from this collection."}
          </p>
        </section>

        <div className="border-t border-beige-200 pt-8">

          {loading ? (
            <p className="text-center py-16 text-beige-600">
              Loading products...
            </p>
          ) : error ? (
            <p className="text-center py-16 text-red-600">
              {error}
            </p>
          ) : products.length > 0 ? (
            <>
              <p className="text-sm text-beige-600 mb-6">
                {products.length} products available
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.map((product) => (
                  <ProductCard
                    key={product._id}
                    product={product}
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-20">
              <h2 className="text-xl font-semibold text-beige-900">
                No products found
              </h2>

              <p className="text-beige-600 mt-2">
                There are currently no products in this category.
              </p>
            </div>
          )}

        </div>
      </div>
    </main>
  );
}

export default Category;
