
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        beige: {
          50: "#FAF9F6",
          100: "#F5F2ED",
          200: "#EEEAE4",
          300: "#E2D9CE",
          400: "#CBBBAA",
          500: "#B5A08B",
          600: "#A58B73",
          700: "#89715C",
          800: "#625246",
          900: "#39332D",
        },
      },
    },
  },
  plugins: [],
};
